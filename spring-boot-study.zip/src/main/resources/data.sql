INSERT INTO employee(employee_id, employee_name, age) VALUES (1, 'yamadatarou', 30);
INSERT INTO employee(employee_id, employee_name, age) VALUES (2, 'nakajimayuuya', 25);
INSERT INTO employee(employee_id, employee_name, age) VALUES (3, 'akiyamakousuke', 34);